# Madrid Warrior - রিলিজ এবং ডিপ্লয়মেন্ট গাইড

## পার্ট ১: APK তৈরি এবং সাইন করা

### স্টেপ 1: Signed APK তৈরি করুন

**Android Studio এ:**
```
1. Build → Generate Signed Bundle/APK
2. Select: APK
3. Create New Keystore
   - Key store path: /your/path/madrid-warrior.jks
   - Password: Your_Secure_Password
   - Key alias: madrid-warrior-key
   - Key password: Same_Or_Different
4. Select: release
5. Enable: V1 Signature & V2 Signature
6. Finish
```

### স্টেপ 2: APK অপ্টিমাইজ করুন

**Output folder:** `app/release/`

আপনার signed APK পাবেন:
```
app-release.apk (সম্পূর্ণ APK)
```

---

## পার্ট ২: Website এ APK হোস্ট করা

### Option A: সরল HTML ডাউনলোড পেজ

আমি আপনার জন্য একটি ready-to-use website তৈরি করেছি।

### Option B: Firebase Hosting এ (ফ্রি)

```bash
# Firebase CLI ইনস্টল
npm install -g firebase-tools

# Firebase এ লগইন
firebase login

# প্রজেক্ট ইনিশিয়ালাইজ করুন
firebase init hosting

# APK এ রাখুন
cp app/release/app-release.apk public/madrid-warrior.apk

# ডিপ্লয় করুন
firebase deploy
```

### Option C: Custom সার্ভার (Recommended)

```bash
# Linux/Ubuntu এ
mkdir -p /var/www/madrid-warrior
cp app-release.apk /var/www/madrid-warrior/
chmod 644 /var/www/madrid-warrior/app-release.apk
```

---

## পার্ট ৩: Website সেটআপ

আপনার মূল website (`madridwarrior.com`) এ এই section যোগ করুন:

```html
<section class="download-section">
  <h2>Madrid Warrior App ডাউনলোড করুন</h2>
  <a href="/download/madrid-warrior.apk" class="btn-download">
    APK ডাউনলোড করুন
  </a>
</section>
```

---

## কিভাবে ইনস্টল করবে ব্যবহারকারীরা?

### Android ফোনে:

1. **ডাউনলোড করুন**
   - Website থেকে APK ডাউনলোড করুন

2. **এক্সেস দিন**
   - Settings → Security → Unknown Sources (ON)

3. **ইনস্টল করুন**
   - ডাউনলোড করা APK tap করুন
   - Install tap করুন
   - Done!

---

## সিকিউরিটি চেকলিস্ট

- [ ] APK signed করা হয়েছে
- [ ] Website HTTPS তে আছে (SSL সার্টিফিকেট)
- [ ] APK file কমপ্রেস করা (optional)
- [ ] Firewall rules যোগ করা
- [ ] Version tracking setup করা

---

## আপডেট ম্যানেজমেন্ট

### নতুন version release করতে:

1. Code update করুন
2. `build.gradle` এ version বাড়ান
   ```
   versionCode 2  // বাড়ান
   versionName "1.1"  // বাড়ান
   ```
3. নতুন signed APK তৈরি করুন
4. Website এ replace করুন
5. Change log update করুন

---

## ডাউনলোড সিস্টেম

### ট্র্যাকিং করতে (optional):

```python
# download_tracker.py
import os
from datetime import datetime

downloads_log = "downloads.log"

def log_download(version="1.0"):
    with open(downloads_log, 'a') as f:
        f.write(f"{datetime.now()} - Downloaded v{version}\n")

def get_download_count():
    if not os.path.exists(downloads_log):
        return 0
    with open(downloads_log, 'r') as f:
        return len(f.readlines())
```

---

## ফাইল সাইজ অপ্টিমাইজেশন

**Default APK size:** ~20-30 MB

**কমাতে:**
1. Unused resources remove করুন
2. ProGuard enable করুন (আছে)
3. WebP images ব্যবহার করুন
4. Split APKs তৈরি করুন

```gradle
// build.gradle এ
bundle {
    enableSplit = true
}
```

---

## সাপোর্ট এবং বাগ রিপোর্টিং

Website এ যোগ করুন:

```
Support Email: support@madridwarrior.com
Issues: https://github.com/yourusername/madrid-warrior/issues
WhatsApp: +880XXXXXXXXX
```

---

## লিগ্যাল এবং আইনি

আপনার website এ যোগ করুন:

- Privacy Policy
- Terms of Service
- License Information
- About the App

---

**পরবর্তী ধাপ: Download page তৈরি করছি...**
