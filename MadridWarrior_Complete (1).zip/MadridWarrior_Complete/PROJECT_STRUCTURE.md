# Madrid Warrior - প্রজেক্ট স্ট্রাকচার সম্পূর্ণ ম্যাপ

সম্পূর্ণ প্রজেক্ট লেআউট এবং সমস্ত ফাইলের ব্যাখ্যা।

---

## 📁 প্রজেক্ট স্ট্রাকচার ট্রি

```
MadridWarrior_Complete/
│
├── 📄 README.md                          # প্রজেক্ট পরিচয় এবং বৈশিষ্ট্য
├── 📄 QUICK_START.md                     # দ্রুত শুরু করার গাইড (৫ মিনিট)
├── 📄 SETUP_GUIDE.md                     # বিস্তারিত সেটআপ নির্দেশাবলী
├── 📄 DATABASE_SCHEMA.md                 # ডাটাবেস ডিজাইন এবং মডেল
├── 📄 API_SCHEMA.md                      # REST API ডকুমেন্টেশন
├── 📄 PROJECT_STRUCTURE.md               # এই ফাইল
│
├── 📁 app/                               # মূল অ্যাপ্লিকেশন মডিউল
│   │
│   ├── 📁 src/
│   │   │
│   │   ├── 📁 main/
│   │   │   │
│   │   │   ├── 📄 AndroidManifest.xml   # অ্যাপ কনফিগারেশন
│   │   │   │
│   │   │   ├── 📁 java/com/mw/app/
│   │   │   │   │
│   │   │   │   ├── 📄 MainActivity.java  # প্রধান অ্যাক্টিভিটি
│   │   │   │   │
│   │   │   │   ├── 📁 data/              # ডেটা লেয়ার
│   │   │   │   │   ├── 📁 models/       # ডেটা মডেল ক্লাস
│   │   │   │   │   ├── 📁 db/           # Room ডাটাবেস
│   │   │   │   │   ├── 📁 api/          # Retrofit API ইন্টারফেস
│   │   │   │   │   └── 📁 repo/         # রিপোজিটরি প্যাটার্ন
│   │   │   │   │
│   │   │   │   ├── 📁 ui/                # UI লেয়ার
│   │   │   │   │   ├── 📁 home/         # হোম স্ক্রিন
│   │   │   │   │   ├── 📁 news/         # খবর স্ক্রিন
│   │   │   │   │   ├── 📁 community/    # কমিউনিটি স্ক্রিন
│   │   │   │   │   ├── 📁 blood/        # রক্ত ব্যাংক স্ক্রিন
│   │   │   │   │   ├── 📁 profile/      # প্রোফাইল স্ক্রিন
│   │   │   │   │   └── 📁 adapters/     # RecyclerView অ্যাডাপ্টার
│   │   │   │   │
│   │   │   │   ├── 📁 viewmodels/       # ViewModel ক্লাস (MVVM)
│   │   │   │   │
│   │   │   │   ├── 📁 utils/            # ইউটিলিটি ক্লাস
│   │   │   │   │   ├── Constants.java
│   │   │   │   │   ├── SharedPrefsManager.java
│   │   │   │   │   └── DateFormatter.java
│   │   │   │   │
│   │   │   │   ├── 📁 services/         # ব্যাকগ্রাউন্ড সার্ভিস
│   │   │   │   │   ├── NotificationService.java
│   │   │   │   │   └── SyncService.java
│   │   │   │   │
│   │   │   │   └── 📁 exceptions/       # কাস্টম এক্সেপশন
│   │   │   │
│   │   │   ├── 📁 res/                  # রিসোর্স ফাইল
│   │   │   │   │
│   │   │   │   ├── 📁 layout/           # XML লেআউট ফাইল
│   │   │   │   │   ├── activity_main.xml
│   │   │   │   │   ├── fragment_home.xml
│   │   │   │   │   ├── fragment_news.xml
│   │   │   │   │   ├── fragment_community.xml
│   │   │   │   │   ├── fragment_blood_bank.xml
│   │   │   │   │   └── fragment_profile.xml
│   │   │   │   │
│   │   │   │   ├── 📁 drawable/         # ড্রয়েবল রিসোর্স
│   │   │   │   │   ├── ic_home.png
│   │   │   │   │   ├── ic_news.png
│   │   │   │   │   ├── ic_community.png
│   │   │   │   │   ├── ic_blood.png
│   │   │   │   │   ├── ic_profile.png
│   │   │   │   │   ├── card_background.xml
│   │   │   │   │   └── (সব অন্যান্য আইকন)
│   │   │   │   │
│   │   │   │   ├── 📁 values/           # রিসোর্স ভ্যালু (লাইট থিম)
│   │   │   │   │   ├── colors.xml       # রঙ ডিফিনিশন
│   │   │   │   │   ├── strings.xml      # সব টেক্সট স্ট্রিং
│   │   │   │   │   ├── themes.xml       # থিম এবং স্টাইল
│   │   │   │   │   ├── dimens.xml       # আকার এবং মার্জিন
│   │   │   │   │   └── attrs.xml        # কাস্টম অ্যাট্রিবিউট
│   │   │   │   │
│   │   │   │   ├── 📁 values-night/     # ডার্ক থিম রিসোর্স
│   │   │   │   │   ├── colors.xml
│   │   │   │   │   └── themes.xml
│   │   │   │   │
│   │   │   │   ├── 📁 navigation/       # নেভিগেশন গ্রাফ
│   │   │   │   │   └── nav_graph.xml    # ফ্রাগমেন্ট নেভিগেশন
│   │   │   │   │
│   │   │   │   ├── 📁 menu/             # মেনু রিসোর্স
│   │   │   │   │   ├── bottom_nav_menu.xml
│   │   │   │   │   └── options_menu.xml
│   │   │   │   │
│   │   │   │   ├── 📁 font/             # কাস্টম ফন্ট
│   │   │   │   │   └── roboto_regular.ttf
│   │   │   │   │
│   │   │   │   ├── 📁 mipmap-mdpi/      # লঞ্চার আইকন (48x48)
│   │   │   │   ├── 📁 mipmap-hdpi/      # লঞ্চার আইকন (72x72)
│   │   │   │   ├── 📁 mipmap-xhdpi/     # লঞ্চার আইকন (96x96)
│   │   │   │   ├── 📁 mipmap-xxhdpi/    # লঞ্চার আইকন (144x144)
│   │   │   │   │
│   │   │   │   └── 📁 raw/              # অন্যান্য রিসোর্স
│   │   │   │
│   │   │   └── 📁 assets/               # অ্যাপ অ্যাসেট
│   │   │       ├── fonts/
│   │   │       ├── images/
│   │   │       └── data/
│   │   │
│   │   ├── 📁 test/                     # ইউনিট টেস্ট
│   │   │   └── java/com/mw/app/
│   │   │       ├── NewsViewModelTest.java
│   │   │       └── DonorRepositoryTest.java
│   │   │
│   │   └── 📁 androidTest/              # ইন্সট্রুমেন্টেড টেস্ট
│   │       └── java/com/mw/app/
│   │           └── MainActivityTest.java
│   │
│   ├── 📄 build.gradle                  # মডিউল লেভেল বিল্ড স্ক্রিপ্ট
│   ├── 📄 proguard-rules.pro             # ProGuard কনফিগারেশন
│   └── 📄 .gitignore                    # গিট ইগনোর ফাইল
│
├── 📄 build.gradle                      # প্রজেক্ট লেভেল বিল্ড স্ক্রিপ্ট
├── 📄 settings.gradle                   # গ্র্যাডেল সেটিংস
├── 📄 gradle.properties                 # গ্র্যাডেল প্রপার্টিজ
├── 📄 local.properties                  # স্থানীয় সেটিংস (গিটইগনোর করা)
│
└── 📄 .gitignore                        # গিট ইগনোর রুলস

```

---

## 📦 মূল কম্পোনেন্ট

### ১. MainActivity.java

```java
মূল এন্ট্রি পয়েন্ট
- বটম নেভিগেশন ম্যানেজ করে
- ফ্রাগমেন্ট ট্রানজিশন হ্যান্ডেল করে
- ব্যাকপ্রেস লজিক
```

### ২. ডেটা লেয়ার

```
data/
├── models/          # ডেটা মডেল ক্লাস (Kotlin data class)
│   ├── News.kt
│   ├── User.kt
│   ├── Donor.kt
│   └── BloodRequest.kt
│
├── db/              # Room ডাটাবেস
│   ├── AppDatabase.java    # ডাটাবেস ইন্সট্যান্স
│   ├── NewsDao.java        # News এক্সেস অবজেক্ট
│   ├── UserDao.java
│   ├── DonorDao.java
│   └── (অন্যান্য DAO)
│
├── api/             # Retrofit API কল
│   ├── ApiService.java     # API এন্ডপয়েন্ট
│   ├── ApiClient.java      # Retrofit ইনস্ট্যান্স
│   └── ApiResponse.java    # লোকাল API রেসপন্স
│
└── repo/            # রিপোজিটরি (ডেটা অ্যাক্সেস)
    ├── NewsRepository.java      # খবর রিপোজিটরি
    ├── UserRepository.java      # ব্যবহারকারী রিপোজিটরি
    ├── DonorRepository.java     # দাতা রিপোজিটরি
    └── (অন্যান্য)
```

### ৩. UI লেয়ার

```
ui/
├── HomeFragment.java        # হোম স্ক্রিন (খবর + ম্যাচ সেন্টার)
├── NewsFragment.java        # খবর তালিকা এবং ট্যাব
├── CommunityFragment.java   # ফেসবুক ইন্টিগ্রেশন
├── BloodBankFragment.java   # দাতা সার্চ এবং রেজিস্ট্রেশন
├── ProfileFragment.java     # ব্যবহারকারী প্রোফাইল
│
└── adapters/
    ├── NewsAdapter.java         # খবর রিসাইক্লার ভিউ
    ├── DonorAdapter.java        # দাতা রিসাইক্লার ভিউ
    ├── AnnouncementAdapter.java # ঘোষণা রিসাইক্লার ভিউ
    └── (অন্যান্য)
```

### ৪. ViewModel (MVVM প্যাটার্ন)

```
viewmodels/
├── NewsViewModel.java       # খবর স্ক্রিনের লজিক
├── BloodBankViewModel.java  # রক্ত ব্যাংক লজিক
├── ProfileViewModel.java    # প্রোফাইল লজিক
└── (অন্যান্য)
```

### ৫. ইউটিলিটিজ

```
utils/
├── Constants.java           # সব ধ্রুবক এবং কনফিগারেশন
├── SharedPrefsManager.java  # ব্যবহারকারী প্রেফারেন্স
├── DateFormatter.java       # তারিখ ফর্ম্যাটিং
├── NetworkUtils.java        # নেটওয়ার্ক চেক
└── ImageLoader.java         # Glide ইমেজ লোডিং
```

---

## 🎨 রিসোর্স সংগঠন

### Layout ফাইল নেমিং কনভেনশন

```xml
activity_*.xml         <!-- অ্যাক্টিভিটি লেআউট -->
fragment_*.xml         <!-- ফ্রাগমেন্ট লেআউট -->
item_*.xml             <!-- আইটেম রিসাইক্লার ভিউ -->
dialog_*.xml           <!-- ডায়ালগ -->
view_*.xml             <!-- কাস্টম ভিউ -->
```

### Drawable নেমিং কনভেনশন

```
ic_*           <!-- আইকন -->
bg_*           <!-- ব্যাকগ্রাউন্ড -->
shape_*        <!-- আকার ড্রয়েবল -->
selector_*     <!-- স্টেট সিলেক্টর -->
```

### সব আইকন তালিকা

```
ic_home             - হোম ট্যাব
ic_news             - খবর ট্যাব
ic_community        - কমিউনিটি ট্যাব
ic_blood            - রক্ত ট্যাব
ic_profile          - প্রোফাইল ট্যাব
ic_notification     - বিজ্ঞপ্তি
ic_search           - সার্চ
ic_filter           - ফিল্টার
ic_share            - শেয়ার
ic_bookmark         - বুকমার্ক
ic_location         - অবস্থান
ic_phone            - ফোন
ic_whatsapp         - হোয়াটসঅ্যাপ
ic_arrow_right      - ডান তীর
ic_check            - চেক মার্ক
ic_back             - ব্যাক বাটন
ic_menu             - মেনু
ic_settings         - সেটিংস
ic_support          - সাপোর্ট
ic_rules            - নিয়মাবলী
```

---

## 📱 অ্যাক্টিভিটি এবং ফ্রাগমেন্ট ফ্লো

```
MainActivity
│
├── HomeFragment
│   └── (বিভিন্ন বিষয়বস্তু)
│
├── NewsFragment
│   └── NewsDetailFragment (নেভিগেশন)
│
├── CommunityFragment
│   └── (ফেসবুক ইম্বেড)
│
├── BloodBankFragment
│   └── DonorDetailFragment (নেভিগেশন)
│
└── ProfileFragment
    └── (সেটিংস এবং লজআউট)
```

---

## 🔄 ডাটা ফ্লো (MVVM)

```
UI (Fragment/Activity)
    ↓
ViewModel (লজিক এবং স্টেট)
    ↓
Repository (ডেটা অ্যাক্সেস)
    ↓
Data Sources
    ├── Remote API (Retrofit)
    └── Local DB (Room)
```

---

## 📊 ডিপেন্ডেন্সি স্ট্রাকচার

```
AndroidX
├── Fragment
├── Navigation
├── Lifecycle (ViewModel, LiveData)
├── Room (Database)
└── Constraint Layout

Material Design
├── Material Components
├── Bottom Navigation
├── Tabs
└── Cards

Third Party
├── Retrofit (API)
├── Glide (Image Loading)
├── Gson (JSON Parsing)
├── Facebook SDK (Social)
└── Coroutines (Async)
```

---

## 🔒 নিরাপত্তা

```
security/
├── keystore/
│   └── madrid-warrior-key.jks    # স্বাক্ষর কী (গিটইগনোর)
│
└── config/
    ├── local.properties           # সেনসিটিভ কনফিগ
    └── secrets.properties         # API কী এবং টোকেন
```

---

## 📈 বৃদ্ধির জন্য প্রস্তুত

এই প্রজেক্ট সাধারণ প্যাটার্ন অনুসরণ করে নতুন বৈশিষ্ট্য যোগ করা সহজ:

### নতুন স্ক্রিন যোগ করুন

```
1. new_feature/
   ├── NewFeatureFragment.java
   ├── NewFeatureViewModel.java
   └── fragment_new_feature.xml

2. এটি nav_graph.xml এ যোগ করুন

3. নেভিগেশন মেনু আইটেম যোগ করুন
```

### নতুন ডেটা মডেল যোগ করুন

```
1. ডেটা ক্লাস তৈরি করুন (models/)

2. DAO ইন্টারফেস তৈরি করুন (db/)

3. API এন্ডপয়েন্ট যোগ করুন (api/)

4. রিপোজিটরি ক্লাস তৈরি করুন (repo/)

5. ViewModel তৈরি করুন (viewmodels/)
```

---

## ✅ চেকলিস্ট

নতুন ফাইল যোগ করার সময়:

- [ ] সঠিক প্যাকেজে রাখুন
- [ ] সঠিক নেমিং কনভেনশন অনুসরণ করুন
- [ ] JavaDoc মন্তব্য যোগ করুন
- [ ] লাইসেন্স হেডার যোগ করুন (প্রয়োজনে)
- [ ] ইউনিট টেস্ট লিখুন
- [ ] build.gradle আপডেট করুন (যদি নতুন লাইব্রেরি হয়)

---

**প্রজেক্ট সংস্করণ: 1.0**
**শেষ আপডেট: জানুয়ারি 2026**
