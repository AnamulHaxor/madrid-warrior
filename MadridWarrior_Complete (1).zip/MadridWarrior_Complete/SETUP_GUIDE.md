# Madrid Warrior - বিস্তারিত সেটআপ গাইড

একটি সম্পূর্ণ Android অ্যাপ্লিকেশন সেটআপ এবং কাস্টমাইজ করার জন্য ধাপে ধাপে নির্দেশাবলী।

## 📋 প্রয়োজনীয় প্রয়োজনীয়তা

### সফটওয়্যার
- **Android Studio**: ৪.2 বা তার উপরে (সর্বোত্তম: Giraffe)
- **JDK**: 17 বা তার উপরে
- **Android SDK**: Level 34
- **Gradle**: 8.0 বা তার উপরে

### হার্ডওয়্যার (ডেভেলপমেন্টের জন্য)
- 8GB RAM (ন্যূনতম: 4GB)
- 4GB ফ্রি ডিস্ক স্পেস
- USB ডেবাগিং সমর্থন সহ Android ডিভাইস

---

## 🚀 ধাপ ১: প্রজেক্ট সেটআপ

### 1.1 Android Studio খুলুন এবং প্রজেক্ট আমদানি করুন

```bash
1. Android Studio খুলুন
2. File → Open (Ctrl+O)
3. MadridWarrior_Complete ফোল্ডার নির্বাচন করুন
4. OK ক্লিক করুন
```

### 1.2 Gradle সিঙ্ক করুন

```bash
File → Sync Now (Ctrl+Y) অথবা
Build → Clean Project
Build → Rebuild Project
```

**সতর্কতা**: প্রথমবার এটি 5-10 মিনিট সময় নিতে পারে।

---

## 🔐 ধাপ ২: Facebook SDK কনফিগার করুন

### 2.1 Facebook অ্যাপ ID পান

1. Facebook Developer সাইটে যান: https://developers.facebook.com
2. আপনার অ্যাপ তৈরি করুন (বা বিদ্যমান অ্যাপ নির্বাচন করুন)
3. **Settings → Basic** থেকে:
   - **App ID** কপি করুন
   - **App Secret** সংরক্ষণ করুন

### 2.2 Strings.xml আপডেট করুন

`app/src/main/res/values/strings.xml` খুলুন এবং খুঁজুন:

```xml
<string name="facebook_app_id">YOUR_FACEBOOK_APP_ID</string>
<string name="facebook_client_token">YOUR_FACEBOOK_CLIENT_TOKEN</string>
```

আপনার মান দিয়ে প্রতিস্থাপন করুন:

```xml
<string name="facebook_app_id">1234567890</string>
<string name="facebook_client_token">your_client_token_here</string>
```

### 2.3 AndroidManifest.xml আপডেট করুন

`app/src/main/AndroidManifest.xml` খুলুন এবং খুঁজুন:

```xml
<provider
    android:name="com.facebook.FacebookContentProvider"
    android:authorities="com.facebook.app.FacebookContentProvider{YOUR_APP_ID}"
    android:exported="true" />
```

আপডেট করুন:

```xml
<provider
    android:name="com.facebook.FacebookContentProvider"
    android:authorities="com.facebook.app.FacebookContentProvider1234567890"
    android:exported="true" />
```

---

## 🌐 ধাপ ৩: API এন্ডপয়েন্ট কনফিগার করুন

### 3.1 BaseURL সেট করুন

`app/src/main/java/com/mw/app/` এ একটি নতুন ফাইল তৈরি করুন: `ApiConfig.java`

```java
package com.mw.app;

public class ApiConfig {
    // মূল API URL
    public static final String BASE_URL = "https://madridwarrior.com/api/";
    
    // মূল ওয়েবসাইট URL
    public static final String WEBSITE_URL = "https://madridwarrior.com/";
    
    // Facebook URLs
    public static final String FACEBOOK_PAGE_URL = "https://facebook.com/madridwarriorofficial";
    public static final String FACEBOOK_GROUP_URL = "https://www.facebook.com/groups/madridwarriorofficial";
    
    // শপ URL
    public static final String SHOP_URL = "https://madridwarrior.com/shop/";
    
    // সংযোগ সময়সীমা (সেকেন্ডে)
    public static final int CONNECTION_TIMEOUT = 15;
    public static final int READ_TIMEOUT = 15;
    public static final int WRITE_TIMEOUT = 15;
}
```

---

## 🗄️ ধাপ ৪: ডাটাবেস সেটআপ করুন

### 4.1 ডাটাবেস ক্লাস তৈরি করুন

`app/src/main/java/com/mw/app/` এ: `AppDatabase.java`

```java
package com.mw.app;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    // DAO অ্যাক্সেসর
}
```

---

## 🎨 ধাপ ৫: থিম কাস্টমাইজ করুন

### 5.1 রঙ পরিবর্তন করুন

`app/src/main/res/values/colors.xml` খুলুন:

```xml
<!-- প্রধান ব্র্যান্ড রঙ -->
<color name="royal_blue">#1E40AF</color>  <!-- পরিবর্তন করুন -->

<!-- একেন্ট রঙ -->
<color name="success">#10B981</color>
<color name="error">#EF4444</color>
```

### 5.2 ডার্ক থিম কাস্টমাইজ করুন

`app/src/main/res/values-night/colors.xml` তৈরি করুন:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- ডার্ক থিম রঙ -->
    <color name="royal_blue">#3B82F6</color>
    <color name="white">#0F172A</color>
    <!-- অন্যান্য রঙ -->
</resources>
```

---

## 📱 ধাপ ৬: অ্যাপ আইকন সেট করুন

### 6.1 লঞ্চার আইকন প্রতিস্থাপন করুন

1. `app/src/main/res/mipmap-xhdpi/` এ যান
2. `ic_launcher.png` আপনার আইকন দিয়ে প্রতিস্থাপন করুন (192x192px)
3. সব ঘনত্বের জন্য পুনরাবৃত্তি করুন:
   - `mipmap-mdpi/` (48x48px)
   - `mipmap-hdpi/` (72x72px)
   - `mipmap-xhdpi/` (96x96px)
   - `mipmap-xxhdpi/` (144x144px)

---

## ⚙️ ধাপ ৭: বিল্ড ভেরিয়েন্ট কনফিগার করুন

### 7.1 ডেবাগ/রিলিজ সেটিংস

`app/build.gradle` খুলুন:

```gradle
android {
    ...
    buildTypes {
        release {
            minifyEnabled true  // কোড অস্পষ্টকরণ
            shrinkResources true  // অপ্রয়োজনীয় রিসোর্স সরান
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }
    }
    ...
}
```

---

## 🔑 ধাপ ৮: সাইনিং কী তৈরি করুন (রিলিজের জন্য)

### 8.1 Keystore তৈরি করুন

```bash
keytool -genkey -v -keystore ~/madrid-warrior-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias madrid-warrior
```

### 8.2 build.gradle এ কনফিগার করুন

```gradle
android {
    ...
    signingConfigs {
        release {
            storeFile file("/path/to/madrid-warrior-key.jks")
            storePassword "your_password"
            keyAlias "madrid-warrior"
            keyPassword "your_password"
        }
    }
    ...
}
```

---

## 🧪 ধাপ ৯: পরীক্ষা করুন এবং চালান

### 9.1 ইমুলেটর অথবা ডিভাইসে চালান

```bash
1. Run → Run 'app' (Shift+F10)
2. ডিভাইস নির্বাচন করুন
3. OK ক্লিক করুন
```

### 9.2 লজিং অ্যাক্সেস করুন

Android Monitor খুলুন:

```
View → Tool Windows → Logcat (Alt+6)
```

সমস্যা নির্ণয়ের জন্য লগ সার্চ করুন।

---

## 📦 ধাপ ১০: APK বিল্ড করুন

### 10.1 ডেবাগ APK

```bash
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

### 10.2 রিলিজ APK

```bash
Build → Build Bundle(s) / APK(s) → Build Bundle(s)
```

APK অবস্থিত: `app/build/outputs/apk/`

---

## 🚀 ডিপ্লয়মেন্টের জন্য চেকলিস্ট

প্রকাশনার আগে পরীক্ষা করুন:

- [ ] সব পারমিশন AndroidManifest.xml এ সঠিক
- [ ] Facebook অ্যাপ ID এবং টোকেন সঠিক
- [ ] API বেস URL সঠিক এবং কাজ করছে
- [ ] সব ছবি এবং আইকন উচ্চ রেজোলিউশন
- [ ] কোন হার্ড-কোডেড বাস্তব ডেটা নেই
- [ ] ProGuard সঠিকভাবে কনফিগার করা হয়েছে
- [ ] রিলিজ বিল্ড তৈরি এবং স্বাক্ষরিত হয়েছে
- [ ] সব বৈশিষ্ট্য ডিভাইসে পরীক্ষা করা হয়েছে
- [ ] ডার্ক মোড সব স্ক্রিনে কাজ করছে
- [ ] নেটওয়ার্ক এরর হ্যান্ডলিং কাজ করছে

---

## 📞 ট্রাবলশুটিং

### সমস্যা: Gradle সিঙ্ক ব্যর্থ

**সমাধান:**
```bash
File → Invalidate Caches / Restart
// বা
./gradlew clean
./gradlew sync
```

### সমস্যা: Facebook SDK এরর

**সমাধান:**
```xml
<!-- strings.xml এ সঠিক অ্যাপ আইডি নিশ্চিত করুন -->
<!-- AndroidManifest.xml এ সঠিক অথরিটি চেক করুন -->
```

### সমস্যা: APK ইনস্টল ব্যর্থ

**সমাধান:**
```bash
adb uninstall com.mw.app  # পুরানো সংস্করণ আনইনস্টল করুন
adb install app/build/outputs/apk/debug/app-debug.apk
```

### সমস্যা: ক্র্যাশ লগ

**সমাধান:**
```bash
View → Tool Windows → Logcat
# "FATAL EXCEPTION" অনুসন্ধান করুন এবং ট্রেস পড়ুন
```

---

## 📚 পরবর্তী পদক্ষেপ

1. **নিয়মিত খবর আপডেট সেটআপ করুন**
   - Backend API তৈরি করুন (Node.js/Python)
   - ডাটাবেস স্কিমা ডিজাইন করুন

2. **Firebase সেটআপ করুন** (পুশ নোটিফিকেশনের জন্য)
   - Google Play Console অ্যাকাউন্ট তৈরি করুন
   - Firebase প্রজেক্ট সেটআপ করুন

3. **অ্যানালিটিক্স যোগ করুন**
   - Google Analytics এন্টিগ্রেশন
   - ক্রাশ রিপোর্টিং

4. **বিটা টেস্টিং শুরু করুন**
   - Google Play Console এ আপলোড করুন
   - বিটা টেস্টার খুঁজে পান

---

## 📄 দরকারী রিসোর্স

- [Android Documentation](https://developer.android.com/)
- [Facebook SDK Docs](https://developers.facebook.com/docs/android)
- [Material Design Guidelines](https://material.io/)
- [Retrofit Documentation](https://square.github.io/retrofit/)
- [Room Database Guide](https://developer.android.com/training/data-storage/room)

---

**এই গাইড নিয়মিত আপডেট করা হয়। যদি সমস্যা হয়, সর্বশেষ ডকুমেন্টেশন চেক করুন।**

🔵 **Madrid Warrior - রিয়েল মাদ্রিদ ফ্যান কমিউনিটি 🔵**
