# Madrid Warrior - API ডকুমেন্টেশন

সম্পূর্ণ REST API এন্ডপয়েন্ট এবং পেলোড ডকুমেন্টেশন।

---

## 📌 বেস URL

```
https://madridwarrior.com/api/v1/
```

---

## 🔐 অথেন্টিকেশন

সব এন্ডপয়েন্ট (পাবলিক ছাড়া) এর জন্য হেডার প্রয়োজন:

```json
{
  "Authorization": "Bearer {access_token}",
  "Content-Type": "application/json"
}
```

---

## 📰 খবর এন্ডপয়েন্ট

### ১. সব খবর পান

**GET** `/news`

**পারামিটার:**
```
category: string (optional) - "BREAKING", "TRANSFERS", "MATCH", "OFFICIAL"
page: integer (optional, default: 1)
limit: integer (optional, default: 20)
sort: string (optional) - "newest", "oldest"
```

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": "news_001",
      "headline": "রিয়েল মাদ্রিদ ৩-০ ব্যার্সিলোনা জিতেছে",
      "content": "বিস্তারিত খবর...",
      "imageUrl": "https://...",
      "category": "MATCH",
      "timestamp": 1705500000000,
      "author": "Madrid Warrior",
      "isBreaking": true,
      "isPinned": false,
      "shareUrl": "https://madridwarrior.com/news/001",
      "approved": true,
      "declineReason": null,
      "views": 1500,
      "shares": 45
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 10,
    "total_items": 200,
    "items_per_page": 20
  }
}
```

---

### ২. একটি খবর পান

**GET** `/news/{newsId}`

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": {
    "id": "news_001",
    "headline": "...",
    "content": "...",
    "imageUrl": "...",
    "category": "MATCH",
    "timestamp": 1705500000000,
    "author": "Madrid Warrior",
    "isBreaking": true,
    "views": 1500,
    "shares": 45,
    "comments": 230
  }
}
```

---

### ৩. খবর পোস্ট করুন (অ্যাডমিন)

**POST** `/news`

**প্রয়োজনীয় অনুমতি:** ADMIN

**রিকোয়েস্ট বডি:**
```json
{
  "headline": "নতুন খবর শিরোনাম",
  "content": "বিস্তারিত বিষয়বস্তু...",
  "imageUrl": "https://...",
  "category": "BREAKING",
  "isBreaking": true,
  "isPinned": false
}
```

**সফল প্রতিক্রিয়া (201):**
```json
{
  "success": true,
  "data": {
    "id": "news_new_001",
    "headline": "নতুন খবর শিরোনাম",
    "createdAt": 1705500000000
  }
}
```

---

### ৪. খবর আপডেট করুন (অ্যাডমিন)

**PUT** `/news/{newsId}`

**প্রয়োজনীয় অনুমতি:** ADMIN

**রিকোয়েস্ট বডি:**
```json
{
  "headline": "আপডেটেড শিরোনাম",
  "content": "আপডেটেড বিষয়বস্তু",
  "isPinned": true
}
```

---

### ৫. খবর মুছুন (অ্যাডমিন)

**DELETE** `/news/{newsId}`

**প্রয়োজনীয় অনুমতি:** ADMIN

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "message": "খবর সফলভাবে মুছে ফেলা হয়েছে"
}
```

---

## 👥 ব্যবহারকারী এন্ডপয়েন্ট

### ১. ব্যবহারকারী রেজিস্টার করুন

**POST** `/auth/register`

**রিকোয়েস্ট বডি:**
```json
{
  "name": "আহমেদ আলী",
  "email": "ahmed@example.com",
  "password": "secure_password_123",
  "phoneNumber": "+880123456789",
  "location": "ঢাকা"
}
```

**সফল প্রতিক্রিয়া (201):**
```json
{
  "success": true,
  "data": {
    "id": "user_001",
    "name": "আহমেদ আলী",
    "email": "ahmed@example.com",
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc..."
  }
}
```

---

### ২. লগইন করুন

**POST** `/auth/login`

**রিকোয়েস্ট বডি:**
```json
{
  "email": "ahmed@example.com",
  "password": "secure_password_123"
}
```

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": {
    "id": "user_001",
    "name": "আহমেদ আলী",
    "email": "ahmed@example.com",
    "role": "MEMBER",
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc...",
    "expiresIn": 3600
  }
}
```

---

### ৩. প্রোফাইল পান

**GET** `/users/profile`

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": {
    "id": "user_001",
    "name": "আহমেদ আলী",
    "email": "ahmed@example.com",
    "phoneNumber": "+880123456789",
    "location": "ঢাকা",
    "profileImage": "https://...",
    "role": "MEMBER",
    "joinedDate": 1705500000000,
    "bio": "রিয়েল মাদ্রিদ প্রেমী"
  }
}
```

---

### ৪. প্রোফাইল আপডেট করুন

**PUT** `/users/profile`

**রিকোয়েস্ট বডি:**
```json
{
  "name": "আহমেদ আলী খান",
  "phoneNumber": "+880198765432",
  "location": "চট্টগ্রাম",
  "bio": "রিয়েল মাদ্রিদ যোদ্ধা"
}
```

---

## 🩸 রক্ত ব্যাংক এন্ডপয়েন্ট

### ১. দাতা নিবন্ধন করুন

**POST** `/blood-bank/donors/register`

**রিকোয়েস্ট বডি:**
```json
{
  "name": "রহিম হাসান",
  "bloodType": "O+",
  "phoneNumber": "+880111111111",
  "district": "ঢাকা",
  "address": "মোহাখালী, ঢাকা",
  "isAvailable": true
}
```

**সফল প্রতিক্রিয়া (201):**
```json
{
  "success": true,
  "data": {
    "id": "donor_001",
    "name": "রহিম হাসান",
    "bloodType": "O+",
    "verified": false,
    "createdAt": 1705500000000
  }
}
```

---

### ২. দাতা খুঁজুন

**GET** `/blood-bank/donors/search`

**পারামিটার:**
```
bloodType: string (required) - "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"
district: string (optional)
isAvailable: boolean (optional)
page: integer (optional, default: 1)
limit: integer (optional, default: 20)
```

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": "donor_001",
      "name": "রহিম হাসান",
      "bloodType": "O+",
      "phoneNumber": "+880111111111",
      "district": "ঢাকা",
      "isAvailable": true,
      "totalDonations": 5,
      "verified": true
    }
  ],
  "count": 15
}
```

---

### ৩. জরুরি রক্ত অনুরোধ পোস্ট করুন

**POST** `/blood-bank/requests`

**রিকোয়েস্ট বডি:**
```json
{
  "patientName": "ফাতিমা বেগম",
  "bloodType": "B+",
  "units": 2,
  "hospital": "বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয়",
  "district": "ঢাকা",
  "urgency": "CRITICAL",
  "description": "জরুরি অপারেশনের জন্য রক্ত প্রয়োজন",
  "contactPhone": "+880122222222"
}
```

**সফল প্রতিক্রিয়া (201):**
```json
{
  "success": true,
  "data": {
    "id": "req_001",
    "patientName": "ফাতিমা বেগম",
    "bloodType": "B+",
    "status": "OPEN",
    "createdAt": 1705500000000,
    "expiresAt": 1705586400000
  }
}
```

---

### ৪. জরুরি অনুরোধ পান

**GET** `/blood-bank/requests/active`

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": "req_001",
      "patientName": "ফাতিমা বেগম",
      "bloodType": "B+",
      "units": 2,
      "hospital": "বঙ্গবন্ধু শেখ মুজিব মেডিকেল বিশ্ববিদ্যালয়",
      "district": "ঢাকা",
      "urgency": "CRITICAL",
      "status": "OPEN",
      "contactPhone": "+880122222222",
      "createdAt": 1705500000000,
      "expiresAt": 1705586400000
    }
  ]
}
```

---

## 💾 সংরক্ষিত পোস্ট এন্ডপয়েন্ট

### ১. পোস্ট সংরক্ষণ করুন

**POST** `/users/saved-posts`

**রিকোয়েস্ট বডি:**
```json
{
  "newsId": "news_001"
}
```

**সফল প্রতিক্রিয়া (201):**
```json
{
  "success": true,
  "data": {
    "id": "saved_001",
    "newsId": "news_001",
    "savedAt": 1705500000000
  }
}
```

---

### ২. সংরক্ষিত পোস্ট পান

**GET** `/users/saved-posts`

**পারামিটার:**
```
page: integer (optional, default: 1)
limit: integer (optional, default: 20)
```

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": "saved_001",
      "news": {
        "id": "news_001",
        "headline": "...",
        "imageUrl": "..."
      },
      "savedAt": 1705500000000
    }
  ],
  "count": 5
}
```

---

### ৩. সংরক্ষিত পোস্ট মুছুন

**DELETE** `/users/saved-posts/{newsId}`

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "message": "পোস্ট সফলভাবে আনসেভ করা হয়েছে"
}
```

---

## 🔔 বিজ্ঞপ্তি এন্ডপয়েন্ট

### ১. বিজ্ঞপ্তি পান

**GET** `/notifications`

**পারামিটার:**
```
unread_only: boolean (optional)
page: integer (optional, default: 1)
limit: integer (optional, default: 20)
```

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": "notif_001",
      "title": "ব্রেকিং খবর!",
      "body": "রিয়েল মাদ্রিদ আঁতনি রুডিগার স্বাক্ষর করেছে",
      "type": "BREAKING_NEWS",
      "relatedId": "news_001",
      "isRead": false,
      "createdAt": 1705500000000
    }
  ],
  "unread_count": 5
}
```

---

### ২. বিজ্ঞপ্তি পড়া হিসাবে চিহ্নিত করুন

**PUT** `/notifications/{notificationId}/read`

**সফল প্রতিক্রিয়া (200):**
```json
{
  "success": true,
  "message": "বিজ্ঞপ্তি পড়া হিসাবে চিহ্নিত করা হয়েছে"
}
```

---

## ❌ ত্রুটি প্রতিক্রিয়া

সব ত্রুটির জন্য স্ট্যান্ডার্ড ফর্ম্যাট:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "ইনপুট যাচাইকরণ ব্যর্থ",
    "details": {
      "email": "বৈধ ইমেইল প্রয়োজন"
    }
  }
}
```

### সাধারণ ত্রুটি কোড

| কোড | HTTP | বর্ণনা |
|------|------|--------|
| `INVALID_REQUEST` | 400 | অবৈধ অনুরোধ |
| `UNAUTHORIZED` | 401 | অনুপ্রবেশের যোগ্য নয় |
| `FORBIDDEN` | 403 | অনুমতি অস্বীকৃত |
| `NOT_FOUND` | 404 | রিসোর্স পাওয়া যায়নি |
| `CONFLICT` | 409 | সংঘর্ষ (যেমন ডুপ্লিকেট) |
| `SERVER_ERROR` | 500 | সার্ভার ত্রুটি |

---

## 🔄 রেট লিমিটিং

সব API এন্ডপয়েন্ট রেট লিমিটেড:

```
100 রিকোয়েস্ট / মিনিট (প্রতি ব্যবহারকারী)
```

হেডার:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1705500060
```

---

## 📊 Response Headers

প্রতিটি সফল প্রতিক্রিয়া অন্তর্ভুক্ত করে:

```
Content-Type: application/json
X-Request-ID: unique-id
X-Response-Time: 125ms
```

---

**API ভার্সন: 1.0**
**শেষ আপডেট: জানুয়ারি 2026**
