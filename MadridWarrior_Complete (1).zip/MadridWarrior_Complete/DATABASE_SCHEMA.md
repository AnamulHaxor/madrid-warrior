# Madrid Warrior - ডাটাবেস স্কিমা

Room Database এর জন্য সম্পূর্ণ ডাটাবেস স্কিমা এবং ডেটা মডেল।

## 📋 টেবিল সংজ্ঞা

---

## ১. `news` টেবিল

সব খবর এবং আপডেট সংরক্ষণ করে।

### কলাম স্পেসিফিকেশন

| কলাম | ধরন | প্রয়োজনীয় | বর্ণনা |
|------|------|----------|--------|
| `id` | TEXT | ✅ | PRIMARY KEY - অনন্য খবর ID |
| `headline` | TEXT | ✅ | খবরের শিরোনাম |
| `content` | TEXT | ✅ | খবরের বিস্তারিত বিষয়বস্তু |
| `imageUrl` | TEXT | ❌ | খবরের সাথে ছবি URL |
| `category` | TEXT | ✅ | ক্যাটাগরি (Breaking/Transfers/Match/Official) |
| `timestamp` | LONG | ✅ | সময় (মিলিসেকেন্ডে) |
| `author` | TEXT | ✅ | লেখক/সোর্স |
| `isBreaking` | BOOLEAN | ✅ | ব্রেকিং খবর কি না |
| `isPinned` | BOOLEAN | ✅ | শীর্ষে পিন করা কি না |
| `shareUrl` | TEXT | ❌ | শেয়ারিং এর জন্য URL |
| `approved` | BOOLEAN | ✅ | অনুমোদিত কি না |
| `declineReason` | TEXT | ❌ | প্রত্যাখ্যানের কারণ |
| `createdAt` | LONG | ✅ | তৈরির সময় |
| `updatedAt` | LONG | ✅ | আপডেটের সময় |

### Kotlin মডেল

```kotlin
@Entity(tableName = "news")
data class News(
    @PrimaryKey
    val id: String,
    val headline: String,
    val content: String,
    val imageUrl: String? = null,
    val category: String, // "BREAKING", "TRANSFERS", "MATCH", "OFFICIAL"
    val timestamp: Long,
    val author: String,
    val isBreaking: Boolean = false,
    val isPinned: Boolean = false,
    val shareUrl: String? = null,
    val approved: Boolean = true,
    val declineReason: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
```

### ইনডেক্স

```sql
CREATE INDEX idx_news_category ON news(category);
CREATE INDEX idx_news_timestamp ON news(timestamp DESC);
CREATE INDEX idx_news_breaking ON news(isBreaking) WHERE isBreaking = 1;
```

---

## ২. `users` টেবিল

ব্যবহারকারী প্রোফাইল এবং তথ্য সংরক্ষণ করে।

### কলাম স্পেসিফিকেশন

| কলাম | ধরন | প্রয়োজনীয় | বর্ণনা |
|------|------|----------|--------|
| `id` | TEXT | ✅ | PRIMARY KEY - ইউজার ID |
| `name` | TEXT | ✅ | সম্পূর্ণ নাম |
| `email` | TEXT | ✅ | ইমেইল ঠিকানা |
| `phoneNumber` | TEXT | ❌ | ফোন নম্বর |
| `profileImage` | TEXT | ❌ | প্রোফাইল ছবির URL |
| `location` | TEXT | ❌ | জেলা/অঞ্চল |
| `role` | TEXT | ✅ | রোল (MEMBER/MODERATOR/ADMIN) |
| `bio` | TEXT | ❌ | ব্যবহারকারী বায়োগ্রাফি |
| `joinedDate` | LONG | ✅ | যোগদানের তারিখ |
| `isActive` | BOOLEAN | ✅ | সক্রিয় কি না |
| `notificationsEnabled` | BOOLEAN | ✅ | বিজ্ঞপ্তি সক্ষম |
| `lastLogin` | LONG | ❌ | শেষ লগইন সময় |
| `createdAt` | LONG | ✅ | অ্যাকাউন্ট তৈরির সময় |
| `updatedAt` | LONG | ✅ | শেষ আপডেট সময় |

### Kotlin মডেল

```kotlin
@Entity(tableName = "users")
data class User(
    @PrimaryKey
    val id: String,
    val name: String,
    val email: String,
    val phoneNumber: String? = null,
    val profileImage: String? = null,
    val location: String? = null,
    val role: String = "MEMBER", // "MEMBER", "MODERATOR", "ADMIN"
    val bio: String? = null,
    val joinedDate: Long,
    val isActive: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val lastLogin: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
```

---

## ৩. `donors` টেবিল

রক্ত দাতাদের তথ্য সংরক্ষণ করে।

### কলাম স্পেসিফিকেশন

| কলাম | ধরন | প্রয়োজনীয় | বর্ণনা |
|------|------|----------|--------|
| `id` | TEXT | ✅ | PRIMARY KEY - দাতা ID |
| `userId` | TEXT | ✅ | FOREIGN KEY - ব্যবহারকারী |
| `name` | TEXT | ✅ | দাতার নাম |
| `bloodType` | TEXT | ✅ | রক্তের গ্রুপ (A+/A-/B+/B-/O+/O-/AB+/AB-) |
| `phone` | TEXT | ✅ | যোগাযোগ নম্বর |
| `district` | TEXT | ✅ | জেলা |
| `address` | TEXT | ✅ | সম্পূর্ণ ঠিকানা |
| `isAvailable` | BOOLEAN | ✅ | বর্তমানে রক্ত দিতে পারবেন কি না |
| `lastDonationDate` | LONG | ❌ | শেষ রক্তদান তারিখ |
| `nextEligibleDate` | LONG | ❌ | পরবর্তী রক্তদান সম্ভব তারিখ |
| `totalDonations` | INTEGER | ✅ | মোট রক্তদানের সংখ্যা |
| `verified` | BOOLEAN | ✅ | যাচাইকৃত কি না |
| `createdAt` | LONG | ✅ | রেজিস্ট্রেশনের সময় |
| `updatedAt` | LONG | ✅ | শেষ আপডেট সময় |

### Kotlin মডেল

```kotlin
@Entity(
    tableName = "donors",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Donor(
    @PrimaryKey
    val id: String,
    val userId: String,
    val name: String,
    val bloodType: String, // "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"
    val phone: String,
    val district: String,
    val address: String,
    val isAvailable: Boolean = true,
    val lastDonationDate: Long? = null,
    val nextEligibleDate: Long? = null,
    val totalDonations: Int = 0,
    val verified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
```

### ইনডেক্স

```sql
CREATE INDEX idx_donor_blood_type ON donors(bloodType);
CREATE INDEX idx_donor_district ON donors(district);
CREATE INDEX idx_donor_available ON donors(isAvailable) WHERE isAvailable = 1;
```

---

## ৪. `blood_requests` টেবিল

জরুরি রক্ত অনুরোধ সংরক্ষণ করে।

### কলাম স্পেসিফিকেশন

| কলাম | ধরন | প্রয়োজনীয় | বর্ণনা |
|------|------|----------|--------|
| `id` | TEXT | ✅ | PRIMARY KEY - অনুরোধ ID |
| `userId` | TEXT | ✅ | অনুরোধকারীর ID |
| `patientName` | TEXT | ✅ | রোগীর নাম |
| `bloodType` | TEXT | ✅ | প্রয়োজনীয় রক্তের গ্রুপ |
| `units` | INTEGER | ✅ | প্রয়োজনীয় ইউনিট সংখ্যা |
| `hospital` | TEXT | ✅ | হাসপাতালের নাম |
| `district` | TEXT | ✅ | জেলা |
| `urgency` | TEXT | ✅ | জরুরিতা (CRITICAL/URGENT/NORMAL) |
| `status` | TEXT | ✅ | স্ট্যাটাস (OPEN/IN_PROGRESS/FULFILLED/CANCELLED) |
| `description` | TEXT | ❌ | বিস্তারিত বর্ণনা |
| `contactPhone` | TEXT | ✅ | যোগাযোগ নম্বর |
| `createdAt` | LONG | ✅ | অনুরোধের সময় |
| `updatedAt` | LONG | ✅ | আপডেটের সময় |
| `expiresAt` | LONG | ✅ | অনুরোধ মেয়াদ শেষের সময় |

### Kotlin মডেল

```kotlin
@Entity(tableName = "blood_requests")
data class BloodRequest(
    @PrimaryKey
    val id: String,
    val userId: String,
    val patientName: String,
    val bloodType: String,
    val units: Int,
    val hospital: String,
    val district: String,
    val urgency: String = "URGENT", // "CRITICAL", "URGENT", "NORMAL"
    val status: String = "OPEN", // "OPEN", "IN_PROGRESS", "FULFILLED", "CANCELLED"
    val description: String? = null,
    val contactPhone: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val expiresAt: Long
)
```

---

## ৫. `saved_posts` টেবিল

ব্যবহারকারীর সংরক্ষিত পোস্ট ট্র্যাক করে।

### কলাম স্পেসিফিকেশন

| কলাম | ধরন | প্রয়োজনীয় | বর্ণনা |
|------|------|----------|--------|
| `id` | TEXT | ✅ | PRIMARY KEY |
| `userId` | TEXT | ✅ | FOREIGN KEY - ব্যবহারকারী |
| `newsId` | TEXT | ✅ | FOREIGN KEY - খবর |
| `savedAt` | LONG | ✅ | সংরক্ষণের সময় |

### Kotlin মডেল

```kotlin
@Entity(
    tableName = "saved_posts",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = News::class,
            parentColumns = ["id"],
            childColumns = ["newsId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["userId", "newsId"], unique = true)
    ]
)
data class SavedPost(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val newsId: String,
    val savedAt: Long = System.currentTimeMillis()
)
```

---

## ৬. `notifications` টেবিল

ব্যবহারকারী বিজ্ঞপ্তি সংরক্ষণ করে।

### কলাম স্পেসিফিকেশন

| কলাম | ধরন | প্রয়োজনীয় | বর্ণনা |
|------|------|----------|--------|
| `id` | TEXT | ✅ | PRIMARY KEY |
| `userId` | TEXT | ✅ | FOREIGN KEY |
| `title` | TEXT | ✅ | বিজ্ঞপ্তির শিরোনাম |
| `body` | TEXT | ✅ | বিজ্ঞপ্তির বিষয়বস্তু |
| `type` | TEXT | ✅ | ধরন (BREAKING_NEWS/MATCH/BLOOD/ANNOUNCEMENT) |
| `relatedId` | TEXT | ❌ | সংযুক্ত খবর/অনুরোধ ID |
| `isRead` | BOOLEAN | ✅ | পড়া হয়েছে কি না |
| `createdAt` | LONG | ✅ | সৃষ্টির সময় |

---

## 🔄 সম্পর্ক ডায়াগ্রাম

```
users
  │
  ├── donors (1:1)
  ├── blood_requests (1:M)
  ├── saved_posts (1:M)
  └── notifications (1:M)

news
  │
  └── saved_posts (1:M)
```

---

## 📊 ডেটা মাইগ্রেশন

### ভার্সন ১ (শুরু)
- সব টেবিল তৈরি

### ভবিষ্যত মাইগ্রেশন উদাহরণ

```kotlin
@Migration(from = 1, to = 2)
object Migration1To2 : Migration(1, 2) {
    override fun migrate(database: SupportSQLiteDatabase) {
        database.execSQL(
            "ALTER TABLE news ADD COLUMN views INTEGER DEFAULT 0"
        )
    }
}
```

---

## 🔒 নিরাপত্তা

- সব পারসোনাল ডেটা এনক্রিপ্টেড থাকবে
- সেনসিটিভ তথ্য (ফোন নম্বর) স্থানীয় ডাটাবেসে সংরক্ষিত
- নিয়মিত ডেটা ব্যাকআপ নেওয়া হবে

---

**ডেটাবেস সংস্করণ: 1.0**
**শেষ আপডেট: জানুয়ারি 2026**
