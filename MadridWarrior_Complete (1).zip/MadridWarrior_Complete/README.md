# Madrid Warrior - Android App

একটি সম্পূর্ণ, production-ready বাংলাদেশের জন্য তৈরি রিয়েল মাদ্রিদ ফ্যান কমিউনিটি অ্যাপ্লিকেশন।

## 📱 বৈশিষ্ট্য

✅ **বটম নেভিগেশন**
- হোম (সর্বশেষ খবর, ম্যাচ সেন্টার)
- খবর (সমস্ত খবর, ট্রান্সফার, অফিসিয়াল স্টেটমেন্ট)
- কমিউনিটি (ফেসবুক পেজ এবং গ্রুপ ইন্টিগ্রেশন)
- ব্লাড ব্যাংক (দাতা নিবন্ধন, অনুসন্ধান)
- প্রোফাইল (ব্যবহারকারী সেটিংস)

✅ **ডিজাইন**
- হোয়াইট এবং ডার্ক মোড সাপোর্ট
- রয়্যাল ব্লু অ্যাক্সেন্ট কালার
- কার্ড-বেসড লেআউট
- দ্রুত এবং হালকা UI, কোন অপ্রয়োজনীয় অ্যানিমেশন নেই

✅ **ডাটাবেস**
- Room Database ইন্টিগ্রেশন
- অফলাইন সাপোর্ট
- দ্রুত ডাটা অ্যাক্সেস

✅ **API ইন্টিগ্রেশন**
- Retrofit + OkHttp নেটওয়ার্কিং
- Facebook SDK ইন্টিগ্রেশন
- JSON সিরিয়ালাইজেশন

✅ **আধুনিক আর্কিটেকচার**
- MVVM প্যাটার্ন
- LiveData + ViewModel
- Navigation Component
- Kotlin Coroutines

## 📋 প্রজেক্ট স্ট্রাকচার

```
MadridWarrior_Complete/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/
│   │   │   └── com/mw/app/
│   │   │       ├── MainActivity.java
│   │   │       ├── data/
│   │   │       ├── ui/
│   │   │       ├── services/
│   │   │       └── utils/
│   │   └── res/
│   │       ├── layout/
│   │       ├── drawable/
│   │       ├── values/
│   │       ├── values-night/
│   │       └── menu/
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

## 🚀 শুরু করার জন্য

### প্রয়োজনীয়তা
- Android Studio Giraffe বা উপরের সংস্করণ
- JDK 17+
- Android SDK 34
- Gradle 8.0+

### ইনস্টলেশন

1. **Android Studio খুলুন**
   ```bash
   # প্রজেক্ট খুলুন
   File → Open → MadridWarrior_Complete
   ```

2. **Gradle সিঙ্ক করুন**
   ```
   File → Sync Now (অথবা Ctrl+Y)
   ```

3. **Facebook SDK সেটআপ করুন**
   - `app/src/main/res/values/strings.xml` খুলুন
   - আপনার Facebook App ID এবং Client Token যোগ করুন:
   ```xml
   <string name="facebook_app_id">YOUR_APP_ID</string>
   <string name="facebook_client_token">YOUR_CLIENT_TOKEN</string>
   ```

4. **অ্যাপ চালান**
   ```
   Run → Run 'app' (Shift+F10)
   ```

## 📁 ফাইল ওভারভিউ

### Core Files

| ফাইল | বর্ণনা |
|------|--------|
| `MainActivity.java` | মূল অ্যাক্টিভিটি - বটম নেভিগেশন হ্যান্ডলিং |
| `build.gradle` | ডিপেন্ডেন্সি এবং প্লাগইন কনফিগারেশন |
| `AndroidManifest.xml` | অ্যাপ কনফিগারেশন এবং পারমিশন |

### Resource Files

| ফোল্ডার | কনটেন্ট |
|---------|---------|
| `res/layout/` | XML লেআউট ফাইল (সব স্ক্রিনের জন্য) |
| `res/values/` | রঙ, স্ট্রিং, স্টাইল (লাইট থিম) |
| `res/values-night/` | ডার্ক থিম রিসোর্স |
| `res/drawable/` | আইকন এবং ড্রয়েবল |
| `res/menu/` | বটম নেভিগেশন মেনু |

## 🔧 কনফিগারেশন

### API Endpoints

`app/src/main/java/com/mw/app/services/ApiClient.java` এ এন্ডপয়েন্ট যোগ করুন:

```java
public static final String BASE_URL = "https://madridwarrior.com/api/";
```

### ডাটাবেস

Room Database সেটআপের জন্য:

```java
AppDatabase database = Room.databaseBuilder(
    context, 
    AppDatabase.class, 
    "madrid-warrior-db"
).build();
```

### Facebook শেয়ারিং

```java
ShareDialog dialog = new ShareDialog(MainActivity.this);
dialog.show(shareContent);
```

## 🎨 থিমিং

### লাইট থিম (ডিফল্ট)
```xml
<!-- res/values/colors.xml -->
<color name="royal_blue">#1E40AF</color>
<color name="white">#FFFFFF</color>
```

### ডার্ক থিম
```xml
<!-- res/values-night/colors.xml -->
<color name="royal_blue">#3B82F6</color>
<color name="white">#0F172A</color>
```

## 📱 স্ক্রিন অনুসারে বৈশিষ্ট্য

### 🏠 হোম
- ব্রেকিং নিউজ স্লাইডার
- ম্যাচ সেন্টার (লাইভ, আসন্ন, ফলাফল)
- গুরুত্বপূর্ণ ঘোষণা
- ফিচার্ড কমিউনিটি পোস্ট

### 📰 খবর
- সব খবর ট্যাব
- ক্যাটাগরি ফিল্টার
- পোস্ট অনুমোদন/প্রত্যাখ্যান (অ্যাডমিনদের জন্য)
- শেয়ারিং অপশন

### 👥 কমিউনিটি
- ফেসবুক পেজ ইন্টিগ্রেশন
- ফেসবুক গ্রুপ ইন্টিগ্রেশন
- কমিউনিটি নিয়মাবলী

### 🩸 ব্লাড ব্যাংক
- দাতা নিবন্ধন ফর্ম
- রক্তের গ্রুপ অনুযায়ী ফিল্টার
- জেলা-ভিত্তিক অনুসন্ধান
- জরুরি অনুরোধ পোস্ট

### 👤 প্রোফাইল
- ব্যবহারকারী তথ্য
- সংরক্ষিত পোস্ট
- বিজ্ঞপ্তি সেটিংস
- লগআউট

## 🔐 নিরাপত্তা

- HTTPS শুধুমাত্র API কল
- Facebook SDK এর মাধ্যমে সুরক্ষিত প্রমাণীকরণ
- SharedPreferences এনক্রিপশন (ভবিষ্যতে)
- ProGuard অবস্কুরেশন (রিলিজ বিল্ডে)

## 📦 ডিপেন্ডেন্সি

- **Android X**: Modern Android framework
- **Retrofit**: HTTP client
- **Room**: Local database
- **LiveData**: Reactive data binding
- **Navigation**: Fragment navigation
- **Glide**: Image loading
- **Facebook SDK**: Social features
- **Coroutines**: Async operations

## 🧪 পরীক্ষা

### ইউনিট টেস্ট চালান
```bash
./gradlew test
```

### ইন্সট্রুমেন্টেড টেস্ট চালান
```bash
./gradlew connectedAndroidTest
```

## 📚 ডকুমেন্টেশন

### নেভিগেশন গ্রাফ
`app/src/main/res/navigation/nav_graph.xml` তে সব ফ্রাগমেন্ট সংজ্ঞায়িত

### API স্কিমা
দেখুন: `API_SCHEMA.md`

### ডাটাবেস স্কিমা
দেখুন: `DATABASE_SCHEMA.md`

## 🚀 বিল্ড এবং রিলিজ

### ডেবাগ বিল্ড
```bash
./gradlew assembleDebug
```

### রিলিজ বিল্ড
```bash
./gradlew assembleRelease
```

### APK স্বাক্ষর করা
`local.properties` এ keystore তথ্য যোগ করুন এবং:
```bash
./gradlew assembleRelease
```

## 📞 সাপোর্ট এবং যোগাযোগ

- **ওয়েবসাইট**: https://madridwarrior.com
- **ফেসবুক পেজ**: https://facebook.com/madridwarriorofficial
- **ফেসবুক গ্রুপ**: https://facebook.com/groups/madridwarriorofficial

## 📄 লাইসেন্স

এই অ্যাপ্লিকেশন Madrid Warrior সম্প্রদায়ের জন্য তৈরি।

## 🎯 ভবিষ্যত বৈশিষ্ট্য

- [ ] পুশ নোটিফিকেশন
- [ ] অফলাইন সিঙ্ক
- [ ] ভিডিও সাপোর্ট
- [ ] লাইভ ম্যাচ কমেন্টারি
- [ ] প্রিমিয়াম ফিচার
- [ ] ইউজার জেনারেটেড কনটেন্ট

---

**Made with ❤️ for Madrid Warriors in Bangladesh**

🔵 হোয়াইট + রয়্যাল ব্লু 🔵

*Simple. Serious. Community-first.*
