# Madrid Warrior - সার্ভার সেটআপ এবং ডিপ্লয়মেন্ট গাইড

## দ্রুত সেটআপ (৫ মিনিট)

### আপনার যা প্রয়োজন:
- ✅ একটি ডোমেইন (madridwarrior.com)
- ✅ একটি ওয়েব সার্ভার (Linux)
- ✅ SSL সার্টিফিকেট (বিনামূল্যে Let's Encrypt)
- ✅ Signed APK ফাইল

---

## অপশন ১: Firebase Hosting (সবচেয়ে সহজ) ⭐

### ধাপ 1: Firebase Account তৈরি করুন
```
1. firebase.google.com এ যান
2. Sign in with Google
3. Create Project
   - Project name: madrid-warrior
   - Select country: Bangladesh
4. Enable Hosting
```

### ধাপ 2: Firebase CLI ইনস্টল করুন
```bash
# macOS / Linux
curl -sL https://firebase.tools | bash

# Windows
npm install -g firebase-tools
```

### ধাপ 3: Firebase এ লগইন করুন
```bash
firebase login
firebase init hosting
```

### ধাপ 4: APK Deploy করুন
```bash
# public ফোল্ডার তৈরি করুন
mkdir -p public/apk
mkdir -p public/downloads

# APK কপি করুন
cp app/release/app-release.apk public/apk/madrid-warrior-v1.0.apk

# Deploy করুন
firebase deploy
```

### ধাপ 5: Custom Domain সংযোগ করুন
```
Firebase Console → Hosting → Connect Domain
Domain: madridwarrior.com
```

---

## অপশন ২: Linux Server এ (বেশি নিয়ন্ত্রণ)

### প্রয়োজনীয় সফটওয়্যার
```bash
# Ubuntu/Debian এ
sudo apt update
sudo apt install nginx certbot python3-certbot-nginx wget

# CentOS এ
sudo yum install nginx certbot certbot-nginx wget
```

### ধাপ 1: Nginx কনফিগার করুন
```bash
# নতুন config ফাইল তৈরি করুন
sudo nano /etc/nginx/sites-available/madridwarrior
```

**Config Content:**
```nginx
server {
    listen 80;
    server_name madridwarrior.com www.madridwarrior.com;

    root /var/www/madrid-warrior;
    index index.html;

    # APK download endpoint
    location /download/ {
        alias /var/www/madrid-warrior/apk/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Website files
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

### ধাপ 2: SSL Certificate যোগ করুন
```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/madridwarrior /etc/nginx/sites-enabled/

# Verify config
sudo nginx -t

# Get SSL cert
sudo certbot --nginx -d madridwarrior.com -d www.madridwarrior.com

# Restart Nginx
sudo systemctl restart nginx
```

### ধাপ 3: APK ফাইল স্থাপন করুন
```bash
# Directory তৈরি করুন
sudo mkdir -p /var/www/madrid-warrior/apk

# APK কপি করুন
sudo cp app-release.apk /var/www/madrid-warrior/apk/madrid-warrior-v1.0.apk

# Permissions সেট করুন
sudo chmod 644 /var/www/madrid-warrior/apk/madrid-warrior-v1.0.apk
sudo chown www-data:www-data /var/www/madrid-warrior -R
```

### ধাপ 4: Website HTML যোগ করুন
```bash
# আমাদের HTML ফাইল কপি করুন
cp website/index.html /var/www/madrid-warrior/

# CSS ফাইল কপি করুন (যদি থাকে)
cp website/style.css /var/www/madrid-warrior/
```

---

## অপশন ৩: AWS S3 + CloudFront

### ধাপ 1: S3 Bucket তৈরি করুন
```bash
aws s3 mb s3://madridwarrior-apk --region ap-south-1
```

### ধাপ 2: APK Upload করুন
```bash
aws s3 cp app-release.apk s3://madridwarrior-apk/madrid-warrior-v1.0.apk \
  --acl public-read \
  --metadata "version=1.0"
```

### ধাপ 3: CloudFront Distribution তৈরি করুন
```
AWS Console → CloudFront → Create Distribution
Domain: s3://madridwarrior-apk.s3.amazonaws.com
CNAME: downloads.madridwarrior.com
```

---

## অপশন ৪: GitHub Pages (ফ্রি ✅)

### ধাপ 1: Repository তৈরি করুন
```bash
git init madrid-warrior-downloads
cd madrid-warrior-downloads
```

### ধাপ 2: APK যোগ করুন
```bash
mkdir -p apk
cp app-release.apk apk/madrid-warrior-v1.0.apk
cp website/index.html .

git add .
git commit -m "Release v1.0"
git push origin main
```

### ধাপ 3: GitHub Pages Enable করুন
```
Settings → Pages
Source: main branch
Domain: madrid-warrior.github.io
```

---

## ডাউনলোড ট্র্যাকিং সিস্টেম

### PHP স্ক্রিপ্ট (সার্ভার সাইড ট্র্যাকিং)

**File: `/var/www/madrid-warrior/download.php`**

```php
<?php
$version = isset($_GET['v']) ? sanitize($_GET['v']) : '1.0';
$ip = $_SERVER['REMOTE_ADDR'];
$date = date('Y-m-d H:i:s');

// Log download
$log_entry = "$date | IP: $ip | Version: $version\n";
file_put_contents('/var/www/madrid-warrior/logs/downloads.log', $log_entry, FILE_APPEND);

// Increment counter
$counter_file = "/var/www/madrid-warrior/data/download_count.txt";
$count = (int)file_get_contents($counter_file) + 1;
file_put_contents($counter_file, $count);

// Redirect to APK
$apk_file = "/var/www/madrid-warrior/apk/madrid-warrior-v{$version}.apk";
if (file_exists($apk_file)) {
    header('Content-Type: application/vnd.android.package-archive');
    header("Content-Disposition: attachment; filename='madrid-warrior-v{$version}.apk'");
    readfile($apk_file);
} else {
    http_response_code(404);
    echo "APK not found";
}

function sanitize($input) {
    return preg_replace('/[^0-9.]/', '', $input);
}
?>
```

### Download Button Update করুন
```html
<a href="download.php?v=1.0" class="download-btn">
    📥 APK ডাউনলোড করুন
</a>
```

---

## সিকিউরিটি চেকলিস্ট

- [ ] HTTPS সক্রিয় (SSL সার্টিফিকেট)
- [ ] APK ফাইল signature verify হয়েছে
- [ ] Download স্পীড limit করা (optional)
- [ ] IP blocking rules যোগ করা
- [ ] Rate limiting সক্রিয়
- [ ] Logs নিয়মিত check করা

### Rate Limiting (Nginx)
```nginx
limit_req_zone $binary_remote_addr zone=apk_limit:10m rate=5r/m;

location /download/ {
    limit_req zone=apk_limit burst=10 nodelay;
    # ... rest of config
}
```

---

## Version Management

### Directory Structure
```
/var/www/madrid-warrior/
├── apk/
│   ├── madrid-warrior-v1.0.apk
│   ├── madrid-warrior-v1.1.apk
│   └── madrid-warrior-v1.2.apk
├── downloads/
│   └── index.html
├── logs/
│   └── downloads.log
├── data/
│   └── download_count.txt
└── index.html
```

### Version Switch Script
```bash
#!/bin/bash
# switch_version.sh

NEW_VERSION=$1
OLD_VERSION=$2

cd /var/www/madrid-warrior/apk

# Create symlink
ln -sf madrid-warrior-v${NEW_VERSION}.apk madrid-warrior-latest.apk

# Log change
echo "$(date): Switched from v${OLD_VERSION} to v${NEW_VERSION}" >> /var/www/madrid-warrior/logs/version_history.log
```

---

## মনিটরিং এবং রক্ষণাবেক্ষণ

### Cron Job (দৈনিক চেক)
```bash
# /etc/cron.d/madrid-warrior-monitor
0 2 * * * root /scripts/check_server_health.sh
0 * * * * root /scripts/backup_downloads_log.sh
```

### Health Check Script
```bash
#!/bin/bash
# check_server_health.sh

STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://madridwarrior.com)

if [ "$STATUS" != "200" ]; then
    echo "Server down! Status: $STATUS" | mail -s "Madrid Warrior Alert" admin@madridwarrior.com
fi

# Check disk space
DISK=$(df /var/www/madrid-warrior | awk 'NR==2 {print $5}' | sed 's/%//')
if [ "$DISK" -gt 90 ]; then
    echo "Disk usage critical: ${DISK}%" | mail -s "Disk Space Alert" admin@madridwarrior.com
fi
```

---

## স্বয়ংক্রিয় আপডেট সিস্টেম

### App স্বয়ংক্রিয়ভাবে চেক করবে নতুন version এর জন্য

**API Endpoint (Backend এ তৈরি করুন):**
```
GET /api/version/latest
Response:
{
    "version": "1.2",
    "downloadUrl": "https://madridwarrior.com/apk/madrid-warrior-v1.2.apk",
    "releaseNotes": "Bug fixes and improvements",
    "forceUpdate": false
}
```

---

## ট্রাবলশুটিং

### সমস্যা: 404 Error (APK খুঁজে পাবে না)
```bash
# Check file exists
ls -la /var/www/madrid-warrior/apk/

# Check permissions
chmod 644 /var/www/madrid-warrior/apk/*

# Restart server
sudo systemctl restart nginx
```

### সমস্যা: SSL Certificate issue
```bash
# Renew certificate
sudo certbot renew

# Force renewal
sudo certbot renew --force-renewal
```

### সমস্যা: Slow download
```bash
# Check bandwidth
iftop -i eth0

# Check server resources
top
htop
```

---

## Final Checklist

- [ ] Domain configured
- [ ] SSL certificate active
- [ ] APK uploaded and accessible
- [ ] Download page working
- [ ] Server monitoring setup
- [ ] Backups configured
- [ ] Analytics enabled
- [ ] Support email setup

---

**আপনার website এখন APK ডাউনলোড করার জন্য প্রস্তুত! 🚀**
