# Madrid Warrior - দ্রুত শুরু করার গাইড ⚡

**৫ মিনিটের মধ্যে আপনার অ্যাপ চালু করুন!**

---

## ✅ প্রয়োজনীয় যা আপনার কাছে থাকা উচিত

- ✅ Android Studio ইনস্টল করা
- ✅ JDK 17+ ইনস্টল করা
- ✅ একটি USB ডেবাগিং সক্ষম করা অ্যান্ড্রয়েড ফোন অথবা এমুলেটর

---

## 🚀 ধাপ ১: প্রজেক্ট খোলা (১ মিনিট)

```bash
1. Android Studio খুলুন
2. File → Open (Ctrl+O)
3. MadridWarrior_Complete ফোল্ডার নির্বাচন করুন
4. "This app can be installed as a module" সতর্কতা উপেক্ষা করুন
5. OK ক্লিক করুন
```

---

## 🔄 ধাপ ২: Gradle সিঙ্ক (২-৩ মিনিট)

আপনি একটি "Sync Now" বাটন দেখবেন।

```bash
- ক্লিক করুন "Sync Now"
- অথবা: Build → Clean Project → Rebuild Project
```

**অপেক্ষা করুন** - এটি প্রথমবার ৫-১০ মিনিট সময় নিতে পারে।

---

## 🔐 ধাপ ৩: Facebook সেটআপ (২ মিনিট)

### দ্রুত সেটআপ (ফেসবুক ছাড়াই পরীক্ষা করুন)

আপনি ফেসবুক সেটআপ ছাড়াই অ্যাপ চালাতে পারেন। এটি পরে যোগ করুন।

```bash
# আপাতত, এই লাইন খুঁজুন এবং মন্তব্য করুন:
# app/src/main/AndroidManifest.xml এ
<!--
<meta-data
    android:name="com.facebook.sdk.ApplicationId"
    android:value="@string/facebook_app_id" />
-->
```

---

## 📱 ধাপ ৪: অ্যাপ চালান (১ মিনিট)

### বিকল্প A: এমুলেটর ব্যবহার করুন (সহজ)

```bash
1. AVD Manager খুলুন (Tool → Device Manager)
2. একটি ডিভাইস তৈরি করুন বা বিদ্যমান একটি শুরু করুন
3. Run → Run 'app' (Shift+F10)
4. এমুলেটর নির্বাচন করুন
5. "Run" ক্লিক করুন
```

### বিকল্প B: আপনার ফোন ব্যবহার করুন

```bash
1. আপনার ফোনে USB ডেবাগিং সক্ষম করুন
   - Settings → About → Build Number (7 বার ট্যাপ করুন)
   - Settings → Developer Options → USB Debugging (চালু করুন)

2. USB এর মাধ্যমে কম্পিউটারে সংযোগ করুন

3. Run → Run 'app' (Shift+F10)

4. আপনার ফোন নির্বাচন করুন এবং "Run" ক্লিক করুন
```

---

## ✨ সাফল্য!

আপনি দেখতে পাবেন:

```
✅ Madrid Warrior লোগো
✅ নীল এবং সাদা ডিজাইন
✅ নীচের নেভিগেশন বার (5 ট্যাব)
✅ হোম স্ক্রিনে বিষয়বস্তু
```

---

## 🔧 পরবর্তী ধাপ

### এখনই কাস্টমাইজ করুন

1. **অ্যাপের নাম পরিবর্তন করুন**
   ```xml
   app/src/main/res/values/strings.xml
   <string name="app_name">আপনার অ্যাপের নাম</string>
   ```

2. **রঙ পরিবর্তন করুন**
   ```xml
   app/src/main/res/values/colors.xml
   <color name="royal_blue">#আপনার_রঙ</color>
   ```

3. **API URL আপডেট করুন**
   ```
   ApiConfig.java
   public static final String BASE_URL = "আপনার_API_URL";
   ```

### নিয়মিত আপডেট

- সব পোস্ট, খবর এবং ঘোষণা সার্ভার থেকে আসে
- আপনার মাদ্রিদ ওয়ারিয়র ওয়েবসাইটে একটি অ্যাডমিন প্যানেল সেটআপ করুন
- সেখান থেকে বিষয়বস্তু পরিচালনা করুন

---

## 🛠️ সাধারণ সমস্যা

### সমস্যা: "SDK not found" ত্রুটি

```bash
সমাধান:
File → Project Structure → SDK Location
আপনার Android SDK পাথ নির্দিষ্ট করুন
```

### সমস্যা: "Gradle sync failed"

```bash
সমাধান:
File → Invalidate Caches / Restart
OK ক্লিক করুন এবং অপেক্ষা করুন
```

### সমস্যা: অ্যাপ ক্র্যাশ হয়

```bash
সমাধান:
View → Tool Windows → Logcat
লাল ত্রুটি লাইন খুঁজুন এবং পড়ুন
সাধারণত সংযোগ বা অনুপ্রবেশ ত্রুটি
```

### সমস্যা: এমুলেটর চলছে না

```bash
সমাধান:
Tool → Device Manager → "Create Device"
Android 13 বা নতুন নির্বাচন করুন
প্লে বাটন ক্লিক করুন এবং অপেক্ষা করুন
```

---

## 📞 সাহায্য প্রয়োজন?

1. **README.md পড়ুন** - সম্পূর্ণ ডকুমেন্টেশনের জন্য
2. **SETUP_GUIDE.md পড়ুন** - বিস্তারিত সেটআপ নির্দেশনার জন্য
3. **Android Studio সাহায্য** - Help → Android Studio Help

---

## 🎯 আপনার পরবর্তী লক্ষ্য

✅ অ্যাপ চালু করুন এবং পরীক্ষা করুন
✅ কাস্টমাইজেশন সম্পন্ন করুন
✅ ব্যাকএন্ড API সেটআপ করুন
✅ Facebook ইন্টিগ্রেশন করুন
✅ Google Play Store এ আপলোড করুন

---

**Happy Coding! 🔵 Madrid Warriors Forever 🔵**

---

**দরকারী শর্টকাট:**
- Rebuild: Ctrl+F9
- Run: Shift+F10
- Debug: Shift+F9
- Format Code: Ctrl+Alt+L
- Find: Ctrl+F
