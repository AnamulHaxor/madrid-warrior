# Madrid Warrior - APK তৈরি এবং রিলিজ সম্পূর্ণ গাইড

## 📋 সম্পূর্ণ প্রক্রিয়া (শুরু থেকে শেষ পর্যন্ত)

---

## ফেজ ১: APK তৈরি করা (30 মিনিট)

### ধাপ 1.1: Keystore তৈরি করুন

**এটা একবারই করতে হবে:**

```bash
# Linux/Mac
keytool -genkey -v -keystore ~/madrid-warrior.jks -keyalg RSA -keysize 2048 -validity 10000 -alias madrid-warrior

# Windows (CMD)
keytool -genkey -v -keystore C:\madrid-warrior.jks -keyalg RSA -keysize 2048 -validity 10000 -alias madrid-warrior
```

**প্রশ্নের উত্তর দিন:**
```
Keystore password: [your-secure-password]
Re-enter password: [same-password]

Your name: [Your Name]
Organization name: Madrid Warrior
City: Dhaka
State: Bangladesh
Country: BD

Validity: 10000 days

Alias password: [same or different]
```

**আপনি পাবেন:** `madrid-warrior.jks` ফাইল

---

### ধাপ 1.2: Android Studio এ সেটিংস করুন

**File → Project Structure → Signing Configs**

```gradle
signingConfigs {
    release {
        storeFile file('/path/to/madrid-warrior.jks')
        storePassword 'your_keystore_password'
        keyAlias 'madrid-warrior'
        keyPassword 'your_key_password'
    }
}

buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled true
        shrinkResources true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}
```

---

### ধাপ 1.3: APK Generate করুন

**Android Studio Menu এ:**

```
Build → Generate Signed Bundle / APK
  ↓
Select APK
  ↓
Select keystore file (madrid-warrior.jks)
  ↓
Enter passwords
  ↓
Select release variant
  ↓
Select optimizations (V1, V2 both)
  ↓
Finish
```

**Output Location:**
```
app/release/app-release.apk
```

**File Size Check:**
```bash
ls -lh app/release/app-release.apk
# Output: -rw-r--r-- 1 user group 24.5M app/release/app-release.apk
```

---

### ধাপ 1.4: APK Verify করুন

```bash
# Java installed থাকতে হবে
jarsigner -verify -verbose -certs app/release/app-release.apk

# Output:
# sm 19473 Thu Jan 17 16:52:00 GMT+4 2026 resources.arsc
# ...
# jar verified
```

---

## ফেজ ২: Website এ ফাইল রাখা (15 মিনিট)

### Option A: সরল সার্ভার (Linux)

```bash
# সার্ভারে সংযোগ করুন
ssh user@madridwarrior.com

# Directory তৈরি করুন
mkdir -p /var/www/madrid-warrior/apk
mkdir -p /var/www/madrid-warrior/website

# APK কপি করুন (আপনার কম্পিউটার থেকে)
scp app/release/app-release.apk user@madridwarrior.com:/var/www/madrid-warrior/apk/madrid-warrior-v1.0.apk

# Website ফাইল কপি করুন
scp website/index.html user@madridwarrior.com:/var/www/madrid-warrior/

# Permissions সেট করুন
ssh user@madridwarrior.com 'chmod 644 /var/www/madrid-warrior/apk/* && chmod 644 /var/www/madrid-warrior/index.html'
```

---

### Option B: Direct FTP Upload

```bash
# FTP client ব্যবহার করুন (FileZilla, WinSCP, etc.)
Host: madridwarrior.com
Username: your_ftp_username
Password: your_ftp_password

Upload to: /public_html/apk/madrid-warrior-v1.0.apk
Upload to: /public_html/index.html
```

---

### Option C: GitHub Release

```bash
# GitHub repository তৈরি করুন এবং push করুন
git init madrid-warrior
cd madrid-warrior
cp app/release/app-release.apk .
git add app-release.apk
git commit -m "Release v1.0"
git push origin main

# GitHub এ যান → Releases → Create Release
# Upload APK file directly
# Download link: github.com/yourusername/madrid-warrior/releases/download/v1.0/app-release.apk
```

---

## ফেজ ৩: Website কনফিগার করা (10 মিনিট)

### index.html আপডেট করুন

আমাদের template ব্যবহার করুন (আমরা দিয়েছি):

```html
<!-- website/index.html -->
<a href="/apk/madrid-warrior-v1.0.apk" class="download-btn" download>
    📥 APK ডাউনলোড করুন
</a>
```

### Nginx Configuration (যদি আপনার Linux সার্ভার থাকে)

```bash
sudo nano /etc/nginx/sites-available/madridwarrior
```

সামগ্রী:
```nginx
server {
    listen 80;
    server_name madridwarrior.com www.madridwarrior.com;
    root /var/www/madrid-warrior;
    index index.html;

    location /apk/ {
        alias /var/www/madrid-warrior/apk/;
        expires 30d;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## ফেজ ৪: Testing করুন

### Test 1: Website এক্সেস করুন
```bash
curl https://madridwarrior.com
# Response: HTML content
```

### Test 2: APK ডাউনলোড করুন
```bash
wget https://madridwarrior.com/apk/madrid-warrior-v1.0.apk
# Response: Download starts
```

### Test 3: APK Install করুন
```bash
# ফোনে সরাসরি ডাউনলোড করুন এবং ইনস্টল করুন
# বা
adb install app-release.apk  # Android device সংযুক্ত থাকলে
```

---

## ফেজ ৫: প্রোডাকশন চেকলিস্ট

### আগে লঞ্চ করার আগে:

- [ ] **APK Signed?**
  ```bash
  jarsigner -verify app/release/app-release.apk
  ```

- [ ] **Website Live?**
  ```bash
  curl -I https://madridwarrior.com
  # HTTP/2 200 OK
  ```

- [ ] **APK Downloadable?**
  ```bash
  curl -I https://madridwarrior.com/apk/madrid-warrior-v1.0.apk
  # Content-Type: application/vnd.android.package-archive
  ```

- [ ] **SSL Certificate Valid?**
  ```bash
  openssl s_client -connect madridwarrior.com:443
  # Verify return code: 0 (ok)
  ```

- [ ] **Size OK?**
  ```bash
  ls -lh app/release/app-release.apk
  # Size should be < 50MB
  ```

- [ ] **Version Tagged?**
  ```bash
  git tag -a v1.0 -m "Initial release"
  git push origin v1.0
  ```

---

## ফেজ ৬: ঘোষণা এবং মার্কেটিং

### Facebook এ শেয়ার করুন

```
🎉 আপনার জন্য নিয়ে এসেছি Madrid Warrior Android App! 🔵

✨ সম্পূর্ণ নতুন অভিজ্ঞতা:
✅ সর্বশেষ খবর এবং আপডেট
✅ বিশাল ফ্যান কমিউনিটি
✅ ব্লাড ব্যাংক সেবা
✅ দ্রুত এবং হালকা

📥 ডাউনলোড করুন: madridwarrior.com

Android 8.0+ এ কাজ করে।
```

### WhatsApp Broadcast করুন

```
🔵 Madrid Warrior App এসেছে!

আপনার ফোনে রিয়েল মাদ্রিদের সব খবর এক জায়গায়।

ডাউনলোড: madridwarrior.com/apk

Setting → Security → Unknown Sources চালু করে ইনস্টল করুন।
```

---

## ফেজ ৭: আপডেট এবং মেইনটেন্যান্স

### নতুন Version Release করতে:

```bash
# Code আপডেট করুন
# ...your code changes...

# Version বাড়ান (build.gradle)
versionCode 2      # 1 থেকে 2
versionName "1.1"  # "1.0" থেকে "1.1"

# নতুন APK তৈরি করুন
# Build → Generate Signed Bundle/APK

# Server এ আপলোড করুন
scp app/release/app-release.apk user@madridwarrior.com:/var/www/madrid-warrior/apk/madrid-warrior-v1.1.apk

# Symlink update করুন (optional)
ssh user@madridwarrior.com 'ln -sf madrid-warrior-v1.1.apk /var/www/madrid-warrior/apk/latest.apk'

# Announce করুন
```

---

## সম্পূর্ণ কমান্ড লিস্ট (Copy-Paste এর জন্য)

### Build APK
```bash
cd /path/to/MadridWarrior_Complete
./gradlew clean
./gradlew assembleRelease
# Output: app/release/app-release.apk
```

### Upload to Server
```bash
scp app/release/app-release.apk user@madridwarrior.com:/var/www/madrid-warrior/apk/madrid-warrior-v1.0.apk
```

### Verify Download
```bash
wget https://madridwarrior.com/apk/madrid-warrior-v1.0.apk -O test.apk
ls -lh test.apk
```

### Check APK Signature
```bash
jarsigner -verify -verbose app/release/app-release.apk
```

---

## ডাউনলোড লিঙ্ক (সব জায়গায় ব্যবহার করুন)

```
https://madridwarrior.com/apk/madrid-warrior-v1.0.apk
```

---

## সাপোর্ট এবং Troubleshooting

### সমস্যা 1: "এই বিকাশকারী স্বীকৃত নয়"

**সমাধান:**
```
Settings → Security → Enable Unknown Sources
Chrome → Settings → Unknown Sources (On)
```

### সমস্যা 2: Installation ব্যর্থ হয়েছে

**সমাধান:**
```bash
# আগের সংস্করণ আনইনস্টল করুন
adb uninstall com.mw.app

# আবার ইনস্টল করুন
adb install app-release.apk
```

### সমস্যা 3: APK খুব বড়

**সমাধান:**
```gradle
// build.gradle এ যোগ করুন
android {
    bundle {
        density {
            enableSplit = true
        }
        abi {
            enableSplit = true
        }
    }
}
```

---

## ব্যাকআপ এবং সিকিউরিটি

### Keystore Backup করুন
```bash
# Safe place এ রাখুন
cp madrid-warrior.jks ~/backup/madrid-warrior-backup.jks

# Password নোট করুন (safe place এ)
echo "Keystore password: ..." > ~/backup/keystore-info.txt
```

### APK Backup করুন
```bash
# প্রতিটি release backup করুন
cp app/release/app-release.apk backups/madrid-warrior-v1.0-backup.apk
```

---

## সমাপনী

**এখন আপনার কাছে আছে:**
✅ Signed APK (production-ready)
✅ Download website
✅ Server setup guide
✅ Update system
✅ Support system

**পরবর্তী: Facebook/Telegram এ announce করুন এবং ডাউনলোড শুরু হোক! 🚀**

---

**Version History:**
- v1.0 - Initial Release (January 17, 2026)
- ...আপনার আপডেট এখানে আসবে
